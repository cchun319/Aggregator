package test;

import static org.junit.Assert.*;
import org.junit.Test;


/**
 * @author ericfouh
 */
public class TestIndexBuilder
{
    //ToDos

}
